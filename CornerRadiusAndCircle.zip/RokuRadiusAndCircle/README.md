
    m.poster = m.top.findNode("CustomViewPoster") 
    m.poster.width = 500
    m.poster.height = 500
    m.poster.callFunc("configurateCustomRadius", 500, 500, "7", "urlRadius", "pkg:/images/icon.jpg")
